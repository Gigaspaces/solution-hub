. JSHOMEDIR/bin/setenv.sh 
java $GS_JARS:./bin com.gigaspaces.examples.parallelqueue.Feeder
