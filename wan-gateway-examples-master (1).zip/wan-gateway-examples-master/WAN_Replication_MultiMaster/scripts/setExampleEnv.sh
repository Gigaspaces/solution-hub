export NIC_ADDR=127.0.0.1
export GS_HOME=/gigaspaces-xap-premium-10.0.1-ga
export DEPLOY_DIR=../deploy
