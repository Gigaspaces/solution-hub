export JAVA_HOME=/opt/jdk1.8.0_121

# set XAP_NIC_ADDRESS to machine ip
export XAP_NIC_ADDRESS=127.0.0.1

export GS_HOME=/gigaspaces-xap-premium-12.0.1-ga-b16000
export DEPLOY_DIR=../deploy
