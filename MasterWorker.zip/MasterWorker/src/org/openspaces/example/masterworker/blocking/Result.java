package org.openspaces.example.masterworker.blocking;

import com.gigaspaces.annotation.pojo.SpaceClass;

@SpaceClass
public class Result extends Base {
	public Result (){}

}
