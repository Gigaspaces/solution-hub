package org.openspaces.example.masterworker.blocking;

import com.gigaspaces.annotation.pojo.SpaceClass;

@SpaceClass
public class Request extends Base{
	public Request (){}

}
