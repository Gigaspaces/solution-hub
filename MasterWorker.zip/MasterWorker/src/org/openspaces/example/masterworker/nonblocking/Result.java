package org.openspaces.example.masterworker.nonblocking;

import com.gigaspaces.annotation.pojo.SpaceClass;

@SpaceClass
public class Result extends Base {
	public Result (){}

}
