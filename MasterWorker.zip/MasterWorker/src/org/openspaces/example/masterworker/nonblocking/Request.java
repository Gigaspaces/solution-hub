package org.openspaces.example.masterworker.nonblocking;

import com.gigaspaces.annotation.pojo.SpaceClass;

@SpaceClass
public class Request extends Base{
	public Request (){}

}
