﻿using GigaSpaces.Core.Metadata;
using System;

namespace MasterWorkerModel
{
    [SpaceClass]
    public class MasterProcess : BaseProcess
    {
    }
}
